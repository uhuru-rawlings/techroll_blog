<?php
  $connection = mysqli_connect("sql300.epizy.com","epiz_30522141","IKchJmzfFAKT27y","epiz_30522141_rolltechblogs");
  if($connection){

  }else{
      echo('<script>toastr.warning("cannot connect to the server")</script>');
  }
?>