<?php
  if(isset($_COOKIE['logedinuser'])){
    header("location: login.php");
  }
?>